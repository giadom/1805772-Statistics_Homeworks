﻿Public Class Form1
    'A Bitmap is an object used to work with images defined by pixel data.
    Public b As Bitmap
    'Before you can draw lines and shapes, render textm or display and manipulate images
    'with GDI+, you need to create a Graphics object. The Graphics object represents a GDI+
    'drawing surface, and is the object that is used to create graphical images.
    Public g As Graphics
    Public meanPen As New Pen(Color.DarkViolet, 2)
    Public meanOfMeansPen As New Pen(Color.Violet, 2)
    Public varianceOfMeansPen As New Pen(Color.Purple, 2)
    Public variancePen As New Pen(Color.DarkOrange, 2)
    Public meanOfVariancesPen As New Pen(Color.Orange, 2)
    Public varianceOfVariancesPen As New Pen(Color.OrangeRed, 2)
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click

        'Initializes a new instance of the Bitmap with the specified size.
        Me.b = New Bitmap(Me.PictureBox1.Width, Me.PictureBox1.Height)
        'Create a "Graphics" object from a Bitmap. Then use "Graphics"' methods to do what you need to
        'the image and then you can use the image how you need to. Your "Graphics" object is created to
        'enable drawing on another object.
        Me.g = Graphics.FromImage(b)
        Me.g.SmoothingMode = Drawing2D.SmoothingMode.HighQuality
        Me.g.Clear(Color.White)

        Dim noOfSamples As UInteger = TextBox1.Text 'Number of samples to do
        Dim sizeOfSample As UInteger = TextBox1.Text 'Number of elements in a sample
        Const LOWEST_VALUE As UInteger = 1 'Lowest value that can be randomly pick
        Const HIGHEST_VALUE As UInteger = 100 'Highest value that can be randomly pick
        'Since repetitions of an element is allowed, I just pick a random number
        'between LOWEST_VALUE and HIGHEST_VALUE
        Dim RND As New Random()

        Dim minX As Double = 0
        Dim maxX As Double = noOfSamples
        Dim minY As Double = 0
        Dim maxY As Double = 1000

        'Create a new rectangle starting at the x specified in the first argument and at the y specified in the second argument
        'these arguments are, at the end, referred to the PictureBox because the next isntruction is g.DrawRectangle...
        Dim VirtualWindow As New Rectangle(20, 20, Me.b.Width - 40, Me.b.Height - 40)

        g.DrawRectangle(Pens.DarkSlateGray, VirtualWindow)

        Dim sum As UInteger
        Dim mean As Double
        Dim variance As Double
        Dim sumOfPowers As UInteger

        'Declares two list of points
        Dim meanPoints As New List(Of Point)
        Dim variancePoints As New List(Of Point)
        'Declares the variables of the real-World coordinates
        Dim xDevice As Integer
        Dim yDevice As Integer
        'Historical means and variances
        Dim historicalMeans(noOfSamples) As Double
        Dim historicalVariances(noOfSamples) As Double
        'Start sampling
        For x As Integer = 0 To noOfSamples
            Dim sampled(sizeOfSample) As Integer
            sum = 0
            For j As Integer = 0 To sizeOfSample - 1
                sampled(j) = RND.Next(LOWEST_VALUE, HIGHEST_VALUE)
                sum += sampled(j)
            Next
            'Update the mean line
            mean = sum / sizeOfSample
            historicalMeans(x) = mean
            xDevice = FromXRealToXVirtual(x, minX, maxX, VirtualWindow.Left, VirtualWindow.Width)
            yDevice = FromYRealToYVirtual(mean, minY, maxY, VirtualWindow.Top, VirtualWindow.Height)
            meanPoints.Add(New Point(xDevice, yDevice))
            'Update the variance line
            sumOfPowers = 0
            For j As Integer = 0 To sizeOfSample - 1
                sumOfPowers = sumOfPowers + Math.Pow(sampled(j) - mean, 2)
            Next
            variance = sumOfPowers / (sizeOfSample - 1)
            xDevice = FromXRealToXVirtual(x, minX, maxX, VirtualWindow.Left, VirtualWindow.Width)
            yDevice = FromYRealToYVirtual(variance, minY, maxY, VirtualWindow.Top, VirtualWindow.Height)
            variancePoints.Add(New Point(xDevice, yDevice))
            historicalVariances(x) = variance
        Next
        'Draw the line of the mean
        g.DrawLines(meanPen, meanPoints.ToArray)
        'Draw the line of the variance
        g.DrawLines(variancePen, variancePoints.ToArray)


        'Mean and variance of the first distribution
        'Mean operations
        Dim meanOfMeansPoints As New List(Of Point)
        sum = 0
        For j As Integer = 0 To noOfSamples - 1
            sum += historicalMeans(j)
        Next
        mean = sum / noOfSamples
        xDevice = FromXRealToXVirtual(0, minX, maxX, VirtualWindow.Left, VirtualWindow.Width)
        yDevice = FromYRealToYVirtual(mean, minY, maxY, VirtualWindow.Top, VirtualWindow.Height)
        meanOfMeansPoints.Add(New Point(xDevice, yDevice))
        xDevice = FromXRealToXVirtual(noOfSamples, minX, maxX, VirtualWindow.Left, VirtualWindow.Width)
        yDevice = FromYRealToYVirtual(mean, minY, maxY, VirtualWindow.Top, VirtualWindow.Height)
        meanOfMeansPoints.Add(New Point(xDevice, yDevice))
        g.DrawLines(meanOfMeansPen, meanOfMeansPoints.ToArray)
        'Variance operations
        Dim varianceOfMeansPoints As New List(Of Point)
        sumOfPowers = 0
        For j As Integer = 0 To noOfSamples - 1
            sumOfPowers = sumOfPowers + Math.Pow(historicalMeans(j) - mean, 2)
        Next
        variance = sumOfPowers / (noOfSamples - 1)
        xDevice = FromXRealToXVirtual(0, minX, maxX, VirtualWindow.Left, VirtualWindow.Width)
        yDevice = FromYRealToYVirtual(variance, minY, maxY, VirtualWindow.Top, VirtualWindow.Height)
        varianceOfMeansPoints.Add(New Point(xDevice, yDevice))
        xDevice = FromXRealToXVirtual(noOfSamples, minX, maxX, VirtualWindow.Left, VirtualWindow.Width)
        yDevice = FromYRealToYVirtual(variance, minY, maxY, VirtualWindow.Top, VirtualWindow.Height)
        varianceOfMeansPoints.Add(New Point(xDevice, yDevice))
        g.DrawLines(varianceOfMeansPen, varianceOfMeansPoints.ToArray) ' Vengono valori troppo grandi per essere disegnati

        'Mean and variance of the second distribution
        'Mean operations
        Dim meanOfVariancesPoints As New List(Of Point)
        sum = 0
        For j As Integer = 0 To noOfSamples - 1
            sum += historicalVariances(j)
        Next
        mean = sum / noOfSamples
        xDevice = FromXRealToXVirtual(0, minX, maxX, VirtualWindow.Left, VirtualWindow.Width)
        yDevice = FromYRealToYVirtual(mean, minY, maxY, VirtualWindow.Top, VirtualWindow.Height)
        meanOfVariancesPoints.Add(New Point(xDevice, yDevice))
        xDevice = FromXRealToXVirtual(noOfSamples, minX, maxX, VirtualWindow.Left, VirtualWindow.Width)
        yDevice = FromYRealToYVirtual(mean, minY, maxY, VirtualWindow.Top, VirtualWindow.Height)
        meanOfVariancesPoints.Add(New Point(xDevice, yDevice))
        g.DrawLines(meanOfVariancesPen, meanOfVariancesPoints.ToArray)
        'Variance of variances operations
        Dim varianceOfVariancesPoints As New List(Of Point)
        sumOfPowers = 0
        For j As Integer = 0 To noOfSamples - 1
            sumOfPowers = sumOfPowers + Math.Pow(historicalVariances(j) - mean, 2)
        Next
        variance = sumOfPowers / (noOfSamples - 1)
        xDevice = FromXRealToXVirtual(0, minX, maxX, VirtualWindow.Left, VirtualWindow.Width)
        yDevice = FromYRealToYVirtual(variance, minY, maxY, VirtualWindow.Top, VirtualWindow.Height)
        varianceOfVariancesPoints.Add(New Point(xDevice, yDevice))
        xDevice = FromXRealToXVirtual(noOfSamples, minX, maxX, VirtualWindow.Left, VirtualWindow.Width)
        yDevice = FromYRealToYVirtual(variance, minY, maxY, VirtualWindow.Top, VirtualWindow.Height)
        varianceOfVariancesPoints.Add(New Point(xDevice, yDevice))
        g.DrawLines(varianceOfVariancesPen, varianceOfVariancesPoints.ToArray)


        'Plot everything
        Me.PictureBox1.Image = b
    End Sub

    Function FromXRealToXVirtual(X As Double,
                                 minX As Double, maxX As Double,
                                 Left As Integer, W As Integer) As Integer

        If (maxX - minX) = 0 Then
            Return 0
        End If

        Return Left + W * (X - minX) / (maxX - minX)

    End Function

    Function FromYRealToYVirtual(Y As Double,
                                minY As Double, maxY As Double,
                                Top As Integer, H As Integer) As Integer

        If (maxY - minY) = 0 Then
            Return 0
        End If

        Return Top + H - H * (Y - minY) / (maxY - minY)

    End Function

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Label1.Text = "Type the number of samples to do (a number between 0 and " & UInteger.MaxValue & "):"
    End Sub

End Class
