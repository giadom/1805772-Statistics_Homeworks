﻿Public Class Form1
    'A Bitmap is an object used to work with images defined by pixel data.
    Public b As Bitmap
    'Before you can draw lines and shapes, render textm or display and manipulate images
    'with GDI+, you need to create a Graphics object. The Graphics object represents a GDI+
    'drawing surface, and is the object that is used to create graphical images.
    Public g As Graphics
    Public r As New Random
    Public PenTrajectory As New Pen(Color.DarkViolet, 2)
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click

        'Initializes a new instance of the Bitmap with the specified size.
        Me.b = New Bitmap(Me.PictureBox1.Width, Me.PictureBox1.Height)
        'Create a "Graphics" object from a Bitmap. Then use "Graphics"' methods to do what you need to
        'the image and then you can use the image how you need to. Your "Graphics" object is created to
        'enable drawing on another object.
        Me.g = Graphics.FromImage(b)
        Me.g.SmoothingMode = Drawing2D.SmoothingMode.HighQuality
        Me.g.Clear(Color.White)

        Dim TrialsCount As Integer = 100
        Dim NumerOfTrajectories As Integer = 1 'Number of lines to draw
        Dim SuccessProbability As Double = TextBox1.Text

        Dim minX As Double = 0
        Dim maxX As Double = TrialsCount
        Dim minY As Double = 0
        Dim maxY As Double = 10

        'Create a new rectangle starting at the x specified in the first argument and at the y specified in the second argument
        'these arguments are, at the end, referred to the PictureBox because the next isntruction is g.DrawRectangle...
        Dim VirtualWindow As New Rectangle(20, 20, Me.b.Width - 40, Me.b.Height - 40)

        g.DrawRectangle(Pens.DarkSlateGray, VirtualWindow)

        'Start drawing lines
        For i As Integer = 1 To NumerOfTrajectories
            'Declares list of points
            Dim Punti As New List(Of Point)
            Dim Y As Double = 0
            'Make the line to draw
            For X As Integer = 1 To TrialsCount
                Dim Uniform As Double = r.NextDouble
                If Uniform <= SuccessProbability Then
                    Y = Y + 1
                End If
                Dim xDevice As Integer = FromXRealToXVirtual(X, minX, maxX, VirtualWindow.Left, VirtualWindow.Width)
                Dim YDevice As Integer = FromYRealToYVirtual(Y / Math.Sqrt(X), minY, maxY, VirtualWindow.Top, VirtualWindow.Height)
                Punti.Add(New Point(xDevice, YDevice))
            Next
            'Draw the line
            g.DrawLines(PenTrajectory, Punti.ToArray)
        Next

        Me.PictureBox1.Image = b

    End Sub

    Function FromXRealToXVirtual(X As Double,
                                 minX As Double, maxX As Double,
                                 Left As Integer, W As Integer) As Integer

        If (maxX - minX) = 0 Then
            Return 0
        End If

        Return Left + W * (X - minX) / (maxX - minX)

    End Function

    Function FromYRealToYVirtual(Y As Double,
                                minY As Double, maxY As Double,
                                Top As Integer, H As Integer) As Integer

        If (maxY - minY) = 0 Then
            Return 0
        End If

        Return Top + H - H * (Y - minY) / (maxY - minY)

    End Function

End Class
