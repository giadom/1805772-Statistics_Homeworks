﻿Imports System.Math
Public Class Form1
    'A Bitmap is an object used to work with images defined by pixel data.
    Public b As Bitmap
    'Before you can draw lines and shapes, render textm or display and manipulate images
    'with GDI+, you need to create a Graphics object. The Graphics object represents a GDI+
    'drawing surface, and is the object that is used to create graphical images.
    Public g As Graphics

    Public xCoordinates As List(Of Double)
    Public yCoordinates As List(Of Double)
    Function FromXRealToXVirtual(X As Double,
                                 minX As Double, maxX As Double,
                                 Left As Double, W As Double) As Double

        If (maxX - minX) = 0 Then
            Return 0
        End If

        Return Left + W * (X - minX) / (maxX - minX)

    End Function

    Function FromYRealToYVirtual(Y As Double,
                                minY As Double, maxY As Double,
                                Top As Double, H As Double) As Double

        If (maxY - minY) = 0 Then
            Return 0
        End If

        Return Top + H - H * (Y - minY) / (maxY - minY)

    End Function

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Dim planeAc() As UInteger = {0, 0, 0, 0}
        For i As UInteger = 0 To NumericUpDown2.Value - 1
            If xCoordinates(i) >= 0 And yCoordinates(i) >= 0 Then
                'I quadrante
                planeAc(0) += 1
            ElseIf xCoordinates(i) < 0 And yCoordinates(i) >= 0 Then
                'II quadrante
                planeAc(1) += 1
            ElseIf xCoordinates(i) < 0 And yCoordinates(i) < 0 Then
                'III quadrante
                planeAc(2) += 1
            ElseIf xCoordinates(i) >= 0 And yCoordinates(i) < 0 Then
                'IV quadrante
                planeAc(3) += 1
            End If
        Next

        Dim penColor As New Pen(Color.DarkOrange, 10)
        'Initializes a new instance of the Bitmap with the specified size.
        Me.b = New Bitmap(Me.PictureBox2.Width, Me.PictureBox2.Height)
        'Create a "Graphics" object from a Bitmap. Then use "Graphics"' methods to do what you need to
        'the image and then you can use the image how you need to. Your "Graphics" object is created to
        'enable drawing on another object.
        Me.g = Graphics.FromImage(b)
        Me.g.SmoothingMode = Drawing2D.SmoothingMode.HighQuality
        Me.g.Clear(Color.White)
        'Create a new rectangle starting at the x specified in the first argument and at the y specified in the second argument
        'these arguments are, at the end, referred to the PictureBox because the next instruction is g.DrawRectangle...
        Dim VirtualWindow As New Rectangle(20, 20, Me.b.Width - 40, Me.b.Height - 40)
        g.DrawRectangle(Pens.DarkSlateGray, VirtualWindow)

        Dim minX As Double = 0
        Dim maxX As Double = 10
        Dim minY As Double = 0
        Dim maxY As Double = NumericUpDown2.Value

        Dim points As List(Of Point)
        Dim xDevice As Integer
        Dim yDevice As Integer

        'First histogram
        points = New List(Of Point)
        xDevice = FromXRealToXVirtual(2, minX, maxX, VirtualWindow.Left, VirtualWindow.Width)
        yDevice = FromYRealToYVirtual(planeAc(0), minY, maxY, VirtualWindow.Top, VirtualWindow.Height)
        points.Add(New Point(xDevice, yDevice)) 'Point above
        xDevice = FromXRealToXVirtual(2, minX, maxX, VirtualWindow.Left, VirtualWindow.Width)
        yDevice = FromYRealToYVirtual(0, minY, maxY, VirtualWindow.Top, VirtualWindow.Height)
        points.Add(New Point(xDevice, yDevice)) 'Point below
        g.DrawLines(penColor, points.ToArray)

        'Second histogram
        points = New List(Of Point)
        xDevice = FromXRealToXVirtual(4, minX, maxX, VirtualWindow.Left, VirtualWindow.Width)
        yDevice = FromYRealToYVirtual(planeAc(1), minY, maxY, VirtualWindow.Top, VirtualWindow.Height)
        points.Add(New Point(xDevice, yDevice)) 'Point above
        xDevice = FromXRealToXVirtual(4, minX, maxX, VirtualWindow.Left, VirtualWindow.Width)
        yDevice = FromYRealToYVirtual(0, minY, maxY, VirtualWindow.Top, VirtualWindow.Height)
        points.Add(New Point(xDevice, yDevice)) 'Point below
        g.DrawLines(penColor, points.ToArray)

        'Third histogram
        points = New List(Of Point)
        xDevice = FromXRealToXVirtual(6, minX, maxX, VirtualWindow.Left, VirtualWindow.Width)
        yDevice = FromYRealToYVirtual(planeAc(2), minY, maxY, VirtualWindow.Top, VirtualWindow.Height)
        points.Add(New Point(xDevice, yDevice)) 'Point above
        xDevice = FromXRealToXVirtual(6, minX, maxX, VirtualWindow.Left, VirtualWindow.Width)
        yDevice = FromYRealToYVirtual(0, minY, maxY, VirtualWindow.Top, VirtualWindow.Height)
        points.Add(New Point(xDevice, yDevice)) 'Point below
        g.DrawLines(penColor, points.ToArray)

        'Fourth histogram
        points = New List(Of Point)
        xDevice = FromXRealToXVirtual(8, minX, maxX, VirtualWindow.Left, VirtualWindow.Width)
        yDevice = FromYRealToYVirtual(planeAc(3), minY, maxY, VirtualWindow.Top, VirtualWindow.Height)
        points.Add(New Point(xDevice, yDevice)) 'Point above
        xDevice = FromXRealToXVirtual(8, minX, maxX, VirtualWindow.Left, VirtualWindow.Width)
        yDevice = FromYRealToYVirtual(0, minY, maxY, VirtualWindow.Top, VirtualWindow.Height)
        points.Add(New Point(xDevice, yDevice)) 'Point below
        g.DrawLines(penColor, points.ToArray)

        Me.PictureBox2.Image = b
    End Sub

    'r is the distance from the pole, theta is the degree
    'takes in input and yields a radian number
    Function fromPolarToCartesianX(r As Integer, theta As Integer) As Double
        Return r * Math.Cos(theta)
    End Function

    'r is the distance from the pole, theta is the degree
    'takes in input and yields a radian number
    Function fromPolarToCartesianY(r As Integer, theta As Integer) As Double
        Return r * Math.Sin(theta)
    End Function

    'To convert degrees to radians, multiply degrees by pi/180
    Function toRadians(degree As Double) As Double
        Return degree * Math.PI / 180
    End Function

    'To convert radians to degrees, multiply radians by 180/pi
    Function toDegrees(radian As Double) As Double
        Return radian * 180 / Math.PI
    End Function

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim penColor As Pen
        penColor = New Pen(Color.DarkViolet, 5)

        'Initializes a new instance of the Bitmap with the specified size.
        Me.b = New Bitmap(Me.PictureBox2.Width, Me.PictureBox2.Height)
        'Create a "Graphics" object from a Bitmap. Then use "Graphics"' methods to do what you need to
        'the image and then you can use the image how you need to. Your "Graphics" object is created to
        'enable drawing on another object.
        Me.g = Graphics.FromImage(b)
        Me.g.SmoothingMode = Drawing2D.SmoothingMode.HighQuality
        Me.g.Clear(Color.White)
        'Create a new rectangle starting at the x specified in the first argument and at the y specified in the second argument
        'these arguments are, at the end, referred to the PictureBox because the next instruction is g.DrawRectangle...
        Dim VirtualWindow As New Rectangle(20, 20, Me.b.Width - 40, Me.b.Height - 40)
        g.DrawRectangle(Pens.DarkSlateGray, VirtualWindow)


        Dim minX As Double = xCoordinates.Min
        Dim maxX As Double = xCoordinates.Max
        Dim minY As Double = yCoordinates.Min
        Dim maxY As Double = yCoordinates.Max

        Dim points As List(Of Point)
        Dim xDevice As Double
        Dim yDevice As Double
        For i As UInteger = 0 To NumericUpDown2.Value - 1
            points = New List(Of Point)
            xDevice = FromXRealToXVirtual(xCoordinates(i), minX, maxX, VirtualWindow.Left, VirtualWindow.Width)
            yDevice = FromYRealToYVirtual(yCoordinates(i), minY, maxY, VirtualWindow.Top, VirtualWindow.Height)
            points.Add(New Point(xDevice, yDevice))
            xDevice = FromXRealToXVirtual(xCoordinates(i) + 0.1, minX, maxX, VirtualWindow.Left, VirtualWindow.Width)
            points.Add(New Point(xDevice, yDevice))
            g.DrawLines(penColor, points.ToArray)
        Next

        'Draws the origin
        penColor = New Pen(Color.Black, 3)
        points = New List(Of Point)
        xDevice = FromXRealToXVirtual(0, minX, maxX, VirtualWindow.Left, VirtualWindow.Width)
        yDevice = FromYRealToYVirtual(0 + 1, minY, maxY, VirtualWindow.Top, VirtualWindow.Height)
        points.Add(New Point(xDevice, yDevice))
        xDevice = FromXRealToXVirtual(0, minX, maxX, VirtualWindow.Left, VirtualWindow.Width)
        yDevice = FromYRealToYVirtual(0 - 1, minY, maxY, VirtualWindow.Top, VirtualWindow.Height)
        points.Add(New Point(xDevice, yDevice))
        g.DrawLines(penColor, points.ToArray)
        points = New List(Of Point)
        xDevice = FromXRealToXVirtual(0 - 1, minX, maxX, VirtualWindow.Left, VirtualWindow.Width)
        yDevice = FromYRealToYVirtual(0, minY, maxY, VirtualWindow.Top, VirtualWindow.Height)
        points.Add(New Point(xDevice, yDevice))
        xDevice = FromXRealToXVirtual(0 + 1, minX, maxX, VirtualWindow.Left, VirtualWindow.Width)
        yDevice = FromYRealToYVirtual(0, minY, maxY, VirtualWindow.Top, VirtualWindow.Height)
        points.Add(New Point(xDevice, yDevice))
        g.DrawLines(penColor, points.ToArray)

        Me.PictureBox2.Image = b
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        xCoordinates = New List(Of Double)
        yCoordinates = New List(Of Double)
        Dim numberOfCoordinates As UInteger = NumericUpDown2.Value
        'Random variables for polar coordinates
        Dim rRandom As New Random()
        Dim thetaRandom As New Random()
        For i As UInteger = 1 To numberOfCoordinates
            Dim distance As Double = rRandom.Next(1, NumericUpDown1.Value)
            Dim degrees As Double = thetaRandom.Next(0, 299)
            xCoordinates.Add(fromPolarToCartesianX(distance, toRadians(degrees)))
            yCoordinates.Add(fromPolarToCartesianY(distance, toRadians(degrees)))
        Next
        Button1.Enabled = True
        Button2.Enabled = True
    End Sub

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Button1.Enabled = False
        Button2.Enabled = False
    End Sub
End Class
