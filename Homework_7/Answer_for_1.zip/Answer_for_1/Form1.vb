﻿Public Class Form1
    'A Bitmap is an object used to work with images defined by pixel data.
    Public b As Bitmap
    'Before you can draw lines and shapes, render textm or display and manipulate images
    'with GDI+, you need to create a Graphics object. The Graphics object represents a GDI+
    'drawing surface, and is the object that is used to create graphical images.
    Public g As Graphics
    Public darkVioletPen As New Pen(Color.DarkViolet, 2)
    Public brownPen As New Pen(Color.Brown, 1)
    Public Const NumerOfTrajectories As UInteger = 1 'Number of trajectories to draw
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click

        'Initializes a new instance of the Bitmap with the specified size.
        Me.b = New Bitmap(Me.PictureBox1.Width, Me.PictureBox1.Height)
        'Create a "Graphics" object from a Bitmap. Then use "Graphics"' methods to do what you need to
        'the image and then you can use the image how you need to. Your "Graphics" object is created to
        'enable drawing on another object.
        Me.g = Graphics.FromImage(b)
        Me.g.SmoothingMode = Drawing2D.SmoothingMode.HighQuality
        Me.g.Clear(Color.White)

        Dim TrialsCount As UInteger = NumericUpDown1.Value

        Dim r As New Random
        Dim SuccessProbability As Double = TextBox1.Text / TrialsCount 'Biases the success probability thanks to the value provided by the user

        Dim minX As Double = 0
        Dim maxX As Double = TrialsCount
        Dim minY As Double = 0
        Dim maxY As Double = 1

        'Create a new rectangle starting at the x specified in the first argument and at the y specified in the second argument
        'these arguments are, at the end, referred to the PictureBox because the next isntruction is g.DrawRectangle...
        Dim VirtualWindow As New Rectangle(20, 20, Me.b.Width - 40, Me.b.Height - 40)

        g.DrawRectangle(Pens.DarkSlateGray, VirtualWindow)

        Dim puntiTraiettoriaBernoulli As List(Of Point)
        Dim puntiTraiettoriaInterarrivi As List(Of Point)
        Dim Y As Integer
        Dim ac As UInteger = 0
        Dim xDevice As Integer
        Dim yDevice As Integer
        'Start drawing lines
        For i As Integer = 1 To NumerOfTrajectories
            'Declares list of points
            puntiTraiettoriaBernoulli = New List(Of Point)
            puntiTraiettoriaInterarrivi = New List(Of Point)
            Y = 0
            Dim Uniform As Double
            'Make the line to draw
            For X As Integer = 1 To TrialsCount
                Uniform = r.NextDouble
                If Uniform <= SuccessProbability Then
                    Y = Y + 1
                    If ac <> 0 Then
                        'Fix the point of the interarrival distribution
                        xDevice = FromXRealToXVirtual(X, minX, maxX, VirtualWindow.Left, VirtualWindow.Width)
                        yDevice = FromYRealToYVirtual(ac / X, minY, maxY, VirtualWindow.Top, VirtualWindow.Height)
                        puntiTraiettoriaInterarrivi.Add(New Point(xDevice, yDevice))
                    End If
                    ac = 0
                Else
                    ac += 1
                End If
                xDevice = FromXRealToXVirtual(X, minX, maxX, VirtualWindow.Left, VirtualWindow.Width)
                yDevice = FromYRealToYVirtual(Y / X, minY, maxY, VirtualWindow.Top, VirtualWindow.Height)
                puntiTraiettoriaBernoulli.Add(New Point(xDevice, yDevice))
            Next
            If ac <> 0 Then
                'Fix the last point of the interarrival distribution
                xDevice = FromXRealToXVirtual(TrialsCount, minX, maxX, VirtualWindow.Left, VirtualWindow.Width)
                yDevice = FromYRealToYVirtual(ac / TrialsCount, minY, maxY, VirtualWindow.Top, VirtualWindow.Height)
                puntiTraiettoriaInterarrivi.Add(New Point(xDevice, yDevice))
            End If
            'Draw the line of the current trajectory
            g.DrawLines(darkVioletPen, puntiTraiettoriaBernoulli.ToArray)
            'Draw the line of the interarrival distribution
            g.DrawLines(brownPen, puntiTraiettoriaInterarrivi.ToArray)
        Next

        Me.PictureBox1.Image = b
    End Sub

    Function FromXRealToXVirtual(X As Double,
                                 minX As Double, maxX As Double,
                                 Left As Integer, W As Integer) As Integer

        If (maxX - minX) = 0 Then
            Return 0
        End If

        Return Left + W * (X - minX) / (maxX - minX)

    End Function

    Function FromYRealToYVirtual(Y As Double,
                                minY As Double, maxY As Double,
                                Top As Integer, H As Integer) As Integer

        If (maxY - minY) = 0 Then
            Return 0
        End If

        Return Top + H - H * (Y - minY) / (maxY - minY)

    End Function

End Class
