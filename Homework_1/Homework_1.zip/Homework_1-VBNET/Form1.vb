﻿Public Class Form1
    Dim accumulator As Integer = 0
    Dim user As String = "guest"
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        MsgBox("Welcome!")
        Label1.Text = accumulator
        Label3.Text = ""
        Label4.Text = ""
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        MsgBox("Welcome!")
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        If accumulator <= Integer.MaxValue Then
            accumulator = accumulator + 1
            Label1.Text = accumulator
        Else
            MsgBox("Can not increment more: max number reached")
        End If
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        If accumulator >= Integer.MinValue Then
            accumulator = accumulator - 1
            Label1.Text = accumulator
        Else
            MsgBox("Can not decrement more: minumum number reached")
        End If
    End Sub

    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles Button4.Click
        MsgBox("Goodbye " + user)
        End
    End Sub

    Private Sub Button5_Click(sender As Object, e As EventArgs) Handles Button5.Click
        MsgBox("Thank you, I will remember it")
        user = TextBox1.Text
        TextBox1.Enabled = False
    End Sub

    Private Sub Button6_MouseHover(sender As Object, e As EventArgs) Handles Button6.MouseHover
        Me.BackColor = Color.FromArgb(211, 211, 211)
        Label3.Text = "The World is gray"
        Label4.Text = ""
    End Sub

    Private Sub Button7_MouseHover(sender As Object, e As EventArgs) Handles Button7.MouseHover
        Me.BackColor = Color.FromArgb(56, 45, 255)
        Label4.Text = "The World is blue"
        Label3.Text = ""
    End Sub
End Class
