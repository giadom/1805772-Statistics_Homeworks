using System;
using Microsoft.VisualBasic;

namespace Homework1_CS
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private int accumulator = 0;
        private string user = "guest";
        private void Form1_Load(object sender, EventArgs e)
        {
            Interaction.MsgBox("Welcome!");
            label1.Text = accumulator.ToString();
            label3.Text = "";
            label4.Text = "";
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (accumulator >= int.MinValue)
            {
                accumulator = accumulator - 1;
                label1.Text = accumulator.ToString();
            }
            else
                Interaction.MsgBox("Can not decrement more: minumum number reached");
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Interaction.MsgBox("Welcome!");
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (accumulator <= int.MaxValue)
            {
                accumulator = accumulator + 1;
                label1.Text = accumulator.ToString();
            }
            else
                Interaction.MsgBox("Can not increment more: max number reached");
        }

        private void button4_Click(object sender, EventArgs e)
        {
            Interaction.MsgBox("Goodbye " + user);
            System.Environment.Exit(0);
        }

        private void button5_Click(object sender, EventArgs e)
        {
            Interaction.MsgBox("Thank you, I will remember it");
            user = textBox1.Text;
            textBox1.Enabled = false;
        }

        private void Button6_MouseHover(object sender, EventArgs e)
        {
            this.BackColor = Color.FromArgb(211, 211, 211);
            label3.Text = "The World is gray";
            label4.Text = "";
        }

        private void Button7_MouseHover(object sender , EventArgs e)
        {
            this.BackColor = Color.FromArgb(56, 45, 255);
            label4.Text = "The World is blue";
            label3.Text = "";
        }
    }
}