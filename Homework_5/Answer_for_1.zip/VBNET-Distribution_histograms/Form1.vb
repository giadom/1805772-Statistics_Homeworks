﻿Imports System.IO
Public Class Form1
    Dim sum As Integer
    Dim distribution As New Dictionary(Of String, Integer)

    'A Bitmap is an object used to work with images defined by pixel data.
    Public b As Bitmap
    'Before you can draw lines and shapes, render textm or display and manipulate images
    'with GDI+, you need to create a Graphics object. The Graphics object represents a GDI+
    'drawing surface, and is the object that is used to create graphical images.
    Public g As Graphics
    Public PenTrajectory As New Pen(Color.DarkViolet, 5)
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim filePath As String = TextBox1.Text()
        Dim columnToParse = 0 ' Column indicationg the variable of the attribute. (The next column is the accumulator)
        sum = 0
        distribution = New Dictionary(Of String, Integer)

        Using MyReader As New Microsoft.VisualBasic.FileIO.TextFieldParser(filePath)
            MyReader.TextFieldType = Microsoft.VisualBasic.FileIO.FieldType.Delimited
            MyReader.Delimiters = New String() {","}

            'Handles the first line
            Dim fields = MyReader.ReadFields()
            If 0 <= columnToParse And columnToParse < fields.Length Then 'If has been choosen a valid number for the column
                If False = CheckBox1.Checked Then
                    'The first line is not an header, hence I add a new item to the dictionary
                    distribution.Add(fields(columnToParse), fields(columnToParse + 1))
                    sum += fields(columnToParse + 1)
                End If

                'Add the lines of the file to the ListBox
                While Not MyReader.EndOfData
                    fields = MyReader.ReadFields()
                    distribution.Add(fields(columnToParse), fields(columnToParse + 1))
                    sum += fields(columnToParse + 1)
                End While
            End If
        End Using
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        'Initializes a new instance of the Bitmap with the specified size.
        Me.b = New Bitmap(Me.PictureBox1.Width, Me.PictureBox1.Height)
        'Create a "Graphics" object from a Bitmap. Then use "Graphics"' methods to do what you need to
        'the image and then you can use the image how you need to. Your "Graphics" object is created to
        'enable drawing on another object.
        Me.g = Graphics.FromImage(b)
        Me.g.SmoothingMode = Drawing2D.SmoothingMode.HighQuality
        Me.g.Clear(Color.White)

        Dim minX As Double = 0
        Dim maxX As Double = 200
        Dim minY As Double = 0
        Dim maxY As Double = sum

        'Create a new rectangle starting at the x specified in the first argument and at the y specified in the second argument
        'these arguments are, at the end, referred to the PictureBox because the next instruction is g.DrawRectangle...
        Dim VirtualWindow As New Rectangle(20, 20, Me.b.Width - 40, Me.b.Height - 40)

        g.DrawRectangle(Pens.DarkSlateGray, VirtualWindow)

        Dim Punti As New List(Of Point)
        Dim xDevice As Integer
        Dim YDevice As Integer
        Dim offset As Integer = 2
        For Each key As String In distribution.Keys
            Dim value As Integer = distribution(key)
            xDevice = FromXRealToXVirtual(offset, minX, maxX, VirtualWindow.Left, VirtualWindow.Width)
            YDevice = FromYRealToYVirtual(value, minY, maxY, VirtualWindow.Top, VirtualWindow.Height)
            Punti.Add(New Point(xDevice, YDevice)) 'Point above
            xDevice = FromXRealToXVirtual(offset, minX, maxX, VirtualWindow.Left, VirtualWindow.Width)
            YDevice = FromYRealToYVirtual(0, minY, maxY, VirtualWindow.Top, VirtualWindow.Height)
            Punti.Add(New Point(xDevice, YDevice)) 'Point below
            g.DrawLines(PenTrajectory, Punti.ToArray) 'Draws the vertical line

            Punti = New List(Of Point)
            offset += 3
        Next

        PictureBox1.Image = b
    End Sub


    Function FromXRealToXVirtual(X As Double,
                                 minX As Double, maxX As Double,
                                 Left As Integer, W As Integer) As Integer

        If (maxX - minX) = 0 Then
            Return 0
        End If

        Return Left + W * (X - minX) / (maxX - minX)

    End Function

    Function FromYRealToYVirtual(Y As Double,
                                minY As Double, maxY As Double,
                                Top As Integer, H As Integer) As Integer

        If (maxY - minY) = 0 Then
            Return 0
        End If

        Return Top + H - H * (Y - minY) / (maxY - minY)

    End Function

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        'Initializes a new instance of the Bitmap with the specified size.
        Me.b = New Bitmap(Me.PictureBox1.Width, Me.PictureBox1.Height)
        'Create a "Graphics" object from a Bitmap. Then use "Graphics"' methods to do what you need to
        'the image and then you can use the image how you need to. Your "Graphics" object is created to
        'enable drawing on another object.
        Me.g = Graphics.FromImage(b)
        Me.g.SmoothingMode = Drawing2D.SmoothingMode.HighQuality
        Me.g.Clear(Color.White)

        Dim minX As Double = 0
        Dim maxX As Double = sum
        Dim minY As Double = 0
        Dim maxY As Double = 200

        'Create a new rectangle starting at the x specified in the first argument and at the y specified in the second argument
        'these arguments are, at the end, referred to the PictureBox because the next instruction is g.DrawRectangle...
        Dim VirtualWindow As New Rectangle(20, 20, Me.b.Width - 40, Me.b.Height - 40)

        g.DrawRectangle(Pens.DarkSlateGray, VirtualWindow)

        Dim Punti As New List(Of Point)
        Dim xDevice As Integer
        Dim YDevice As Integer
        Dim offset As Integer = 3
        For Each key As String In distribution.Keys
            Dim value As Integer = distribution(key)
            xDevice = FromXRealToXVirtual(value, minX, maxX, VirtualWindow.Left, VirtualWindow.Width)
            YDevice = FromYRealToYVirtual(offset, minY, maxY, VirtualWindow.Top, VirtualWindow.Height)
            Punti.Add(New Point(xDevice, YDevice)) 'Point above
            xDevice = FromXRealToXVirtual(0, minX, maxX, VirtualWindow.Left, VirtualWindow.Width)
            YDevice = FromYRealToYVirtual(offset, minY, maxY, VirtualWindow.Top, VirtualWindow.Height)
            Punti.Add(New Point(xDevice, YDevice)) 'Point below
            g.DrawLines(PenTrajectory, Punti.ToArray) 'Draws the vertical line

            Punti = New List(Of Point)
            offset += 5
        Next

        PictureBox1.Image = b
    End Sub
End Class
